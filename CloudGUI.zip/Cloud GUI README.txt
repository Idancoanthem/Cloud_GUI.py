This program generates clouds as a collection of point drops in 3D space.
It generates cubes full of drops and then stacks cubes in a rectangular shape in the desired size.
The input parameters are as follows:

File name
File type - 1 for CSV, 2 for txt
Distribution type - 1 for constant radii, 2 for uniformly random distribution around the drop size, and 3 for the polydisperse distribution.

SizeX/SizeY/SizeZ - cube size in the three dimensions *in meters*
# of cubes X/# of cubes Y/# of cubes z - number of cubes in each dimension